import React from "react";
import NewExpenseForm from "./new_expense_form/NewExpenseForm";
import './NewExpense.css';
const NewExpense = () => {
    return (
        <div className="new-expense">
            <NewExpenseForm/>
        </div>
    )
}

export default NewExpense;